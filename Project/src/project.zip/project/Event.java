package project;

public abstract class Event {
	int time;
	Individual individuo;
	public Event(int time, Individual individuo) {
		super();
		this.time = time;
		this.individuo = individuo;
	}

}
