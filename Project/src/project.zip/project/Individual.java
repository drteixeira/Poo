package project;

public class Individual {
	int cost=0; //Custo do caminho
	int lenght=0; //Tamanho do caminho
	int dist; //Distância do pto atual, ao final
	int k; //sensibility
	int dparam, rparam, mparam; //parametros para métodos
	int comfort; // =  //Conforto associado
	Coordinate posatual;
	
	public Individual(Grid g, int k, int dparam, int rparam, int mparam) {
		this.dist = g.SetDist(g.pi);
		this.k = k;
		SetComfort(g);
		this.posatual = g.pi;
		this.dparam=dparam;
		this.rparam=rparam;
		this.mparam=mparam;
		this.posatual=g.pi;
	}	
	
	@Override
	public String toString() {
		return "Individual [cost=" + cost + ", lenght=" + lenght + ", dist=" + dist + ", k=" + k + ", dparam=" + dparam
				+ ", rparam=" + rparam + ", mparam=" + mparam + ", comfort=" + comfort + ", posatual=" + posatual + "]";
	}


	public void SetComfort(Grid g) {
		this.comfort = (1-(this.cost-this.lenght+2)/((g.cmax-1)*this.lenght+3))^(this.k)*
				(1-this.dist/(g.n+g.m+1))^(this.k);
	}
	

	
}