package project;

public class Death extends Event {

	public Death(int time, Individual individuo) {
		super(time, individuo);
		// TODO Auto-generated constructor stub
	}

}
