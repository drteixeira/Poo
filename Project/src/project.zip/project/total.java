package project;

public class total {
	Grid g;
	Population p;
	
	public total(Grid g, Population p) {
		super();
		this.g = g;
		this.p = p;
	}
}
